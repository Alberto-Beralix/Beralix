<?
$submit_button_text       = "Generate";
$message_algorithm        = "Algorithm";
$message_amount_length    = "Amount and Length";
$message_symbol_sets      = "Symbol sets";
$message_user_random_seed = "User's Random Seed";
$message_save_settings    = "Save settings in the cookie";
$message_remove_saved     = "Remove saved settings";
$message_command_line     = "Command line";
$message_generated_pass   = "Generated passwords";
$message_yes              = "Yes";
$message_no               = "No";
$submessage_pronounceable = "Pronounceable:";
$submessage_random        = "Random:";
$submessage_num_of_pass   = "Number of passwords to generate:";
$submessage_min_pass_len  = "Min. password length:";
$submessage_max_pass_len  = "Max. password length:";
$submessage_small_lerrers = "Small letters:";
$submessage_cap_letters   = "Capital letters:";
$submessage_numbers       = "Numbers";
$submessage_spec_symbols  = "Special symbols:";
$submessage_seed          = "Seed:";
$submessage_up_to         = "up to 255";
header ("Pragma: no-cache");
?>