<?
// Translated by Bernhard Wesely (mail@weselyb.net)
$submit_button_text       = "Generieren";
$message_algorithm        = "Algorithmus";
$message_amount_length    = "Anzahl und Stellen";
$message_symbol_sets      = "Zeichensatz";
$message_user_random_seed = "Eigener Random Seed";
$message_save_settings    = "Einstellungen in einem cookie speichern";
$message_remove_saved     = "Gespeicherte Einstellungen l&ouml;schen";
$message_command_line     = "Shell-Befehl";
$message_generated_pass   = "Generierte Passw&ouml;rter";
$message_yes              = "Ja";
$message_no               = "Nein";
$submessage_pronounceable = "Aussprechbar:";
$submessage_random        = "Zuf&auml;llig:";
$submessage_num_of_pass   = "Anzahl der zu generierenden Passw&ouml;rter:";
$submessage_min_pass_len  = "Min. Passwort L&auml;nge:";
$submessage_max_pass_len  = "Max. Passwort L&auml;nge:";
$submessage_small_lerrers = "Kleinbuchstaben:";
$submessage_cap_letters   = "Grossbuchstaben:";
$submessage_numbers       = "Nummern";
$submessage_spec_symbols  = "Symbole:";
$submessage_seed          = "Seed:";
$submessage_up_to         = "bis&nbsp;zu&nbsp;255";
header ("Pragma: no-cache");
?>
